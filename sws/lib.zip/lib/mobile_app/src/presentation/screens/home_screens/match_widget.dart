import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:sws/mobile_app/src/config/themes/app_colors.dart';
import 'package:sws/mobile_app/src/presentation/screens/helpers/sized_box.dart';

class HomeMatchWidget extends StatelessWidget {
  const HomeMatchWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return SliverList(
      delegate: SliverChildBuilderDelegate(
        childCount: 6,
            (context, index) {
          return Container(
            margin: const EdgeInsets.only(
              top: 4.0,
              bottom: 8.0,
            ),
            padding: const EdgeInsets.all(8.0),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(8.0),
              color: kDarkColor,
            ),
            height: 72,
            width: double.infinity,
            child: Row(
              children: [
                Expanded(
                  child: Row(
                    children: [
                      Expanded(
                        child: Text(
                          "Real Madrid",
                          textAlign: TextAlign.center,
                          maxLines: 2,
                          style: GoogleFonts.heebo(
                            color: Colors.white,
                            fontSize: 16,
                          ),
                        ),
                      ),
                      WBox(8.0),
                      ClipRRect(
                        borderRadius: BorderRadius.circular(40),
                        child: CachedNetworkImage(
                          height: 40,
                          width: 40,
                          fit: BoxFit.cover,
                          imageUrl:
                          "https://sun1-93.userapi.com/s/v1/ig1/aRX17kUK-TjChMOrYe5g7r6d_NSYre6ZbuQQvdKF8OtHMmizt1wVnp24sSBhf4JzgWP-lVh8.jpg?size=400x400&quality=96&crop=150,0,599,599&ava=1",
                        ),
                      ),
                    ],
                  ),
                ),
                WBox(8.0),
                Column(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    Container(
                      padding: const EdgeInsets.only(
                        left: 8,
                        right: 8,
                        top: 2,
                        bottom: 2,
                      ),
                      decoration: BoxDecoration(
                        color: Colors.greenAccent.shade700,
                        borderRadius: BorderRadius.circular(16),
                      ),
                      child: const Text(
                        "71'",
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 12,
                        ),
                      ),
                    ),
                    // Text(
                    //   "24.08.2023",
                    //   style: GoogleFonts.poppins(
                    //     color: Colors.white,
                    //   ),
                    // ),

                    Text(
                      "0 : 0",
                      style: GoogleFonts.oswald(color: mainColor, fontSize: 22),
                    ),
                  ],
                ),
                WBox(8.0),
                Expanded(
                  child: Row(
                    children: [
                      ClipRRect(
                        borderRadius: BorderRadius.circular(40),
                        child: CachedNetworkImage(
                          height: 40,
                          width: 40,
                          fit: BoxFit.cover,
                          imageUrl:
                          "https://avatanplus.com/files/resources/mid/5776a782aaace155a77e568b.png",
                        ),
                      ),
                      WBox(8.0),
                      Expanded(
                        child: Text(
                          "Barselona ",
                          textAlign: TextAlign.center,
                          maxLines: 2,
                          style: GoogleFonts.heebo(
                            color: Colors.white,
                            fontSize: 16,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}

