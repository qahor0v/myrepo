abstract class ScoreServicesFunctions {
  Future<dynamic> getCountries();

  Future<dynamic> getCompetitions(String id);

  Future<dynamic> getTeams(String id);

  Future<dynamic> getPlayers(String id);

  Future<dynamic> getStandings(String id);

  Future<dynamic> getEvents(String id);

  Future<dynamic> getLineups(String id);

  Future<dynamic> getStats(String id);

  Future<dynamic> getComments(String id);

  Future<dynamic> getHeadToHead(String id);

  Future<dynamic> getWebsockets(String id);
}
