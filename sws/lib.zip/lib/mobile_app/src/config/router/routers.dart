import 'package:flutter/material.dart';

class AppRouter {
  static Map<String, WidgetBuilder> routers = {};
}
