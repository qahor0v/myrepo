const scoreKEY =
    "46ec554e4f695fb37a5f7a254dbf9aad6d8b973dc38b039ccde3cf3ff6faaf5e";
