abstract class AssetIcons {
  static const String ball = "assets/icons/ball.png";
  static const String tv = "assets/icons/television.png";
  static const String league = "assets/icons/champions.png";
  static const String home = "assets/icons/football.png";
  static const String news = "assets/icons/megaphone.png";

}