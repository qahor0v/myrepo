import 'package:sws/mobile_app/src/utils/constants/keys.dart';

class ScoreRequestURLs {
  static String getCountries =
      "https://apiv3.apifootball.com/?action=get_countries&APIkey=$scoreKEY";

  static String getCompetitions(String id) =>
      "https://apiv3.apifootball.com/?action=get_leagues&country_id=$id&APIkey=$scoreKEY";

  static String getTeams(String id) =>
      "https://apiv3.apifootball.com/?action=get_teams&league_id=$id&APIkey=$scoreKEY";
}

class ScoreIDs {
  ///Countries
  static const String uzb = "116";
  static const String saudi = "97";
  static const String usa = "114";
  static const String ru = "95";
  static const String en = "44";
  static const String es = "6";
  static const String it = "5";
  static const String ger = "4";
  static const String fr = "3";
  static const String turk = "111";
  static const String port = "92";
  static const String euroCups = "1";
  static const String europe = "160";
  static const String world = "133";

  ///Leagues
  static const String uzSuperLeague = "335";
  static const String saudiProLeague = "278";
  static const String usaMLS = "332";
  static const String ruPL = "344";
  static const String enChampionship = "153";
  static const String enLeagueCup = "147";
  static const String epl = "152";
  static const String esCopaDelRey = "300";
  static const String laliga = "302";
  static const String serieA = "207";
  static const String serieB = "206";
  static const String coppaIT = "205";
  static const String bundesliga = "171";
  static const String league1 = "168";
  static const String turkeySuperLeague = "322";
  static const String portugalLeague = "266";
  static const String ucl = "3";
  static const String uel = "4";
}
