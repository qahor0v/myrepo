import 'package:flutter/material.dart'
;
class TVPage extends StatelessWidget {
  const TVPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.amber,
    );
  }
}
