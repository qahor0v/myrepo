import 'package:flutter/material.dart';

const mainColor = Color(0xffF4D504);
const darkColor = Color(0xff282A3A);
const kDarkColor = Color(0xff1b1d26);

const baseColor = Colors.grey;
const highlightColor = darkColor;
