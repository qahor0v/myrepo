import 'package:dio/dio.dart';
import 'package:sws/mobile_app/src/domain/repository/score_services/score_services_functions.dart';
import 'package:sws/mobile_app/src/utils/constants/score_sources.dart';

class ScoreServices extends ScoreServicesFunctions {
  static final dio = Dio();

  @override
  Future getComments(String id) {
    // TODO: implement getComments
    throw UnimplementedError();
  }

  @override
  Future getCompetitions(String id) async {
    final result = await dio.get(ScoreRequestURLs.getCompetitions(id));
    return result;
  }

  @override
  Future getCountries() async {
    final result = await dio.get(ScoreRequestURLs.getCountries);
    return result;
  }

  @override
  Future getEvents(String id) {
    // TODO: implement getEvents
    throw UnimplementedError();
  }

  @override
  Future getHeadToHead(String id) {
    // TODO: implement getHeadToHead
    throw UnimplementedError();
  }

  @override
  Future getLineups(String id) {
    // TODO: implement getLineups
    throw UnimplementedError();
  }

  @override
  Future getPlayers(String id) {
    // TODO: implement getPlayers
    throw UnimplementedError();
  }

  @override
  Future getStandings(String id) {
    // TODO: implement getStandings
    throw UnimplementedError();
  }

  @override
  Future getStats(String id) {
    // TODO: implement getStats
    throw UnimplementedError();
  }

  @override
  Future getTeams(String id) async {
    final result = await dio.get(ScoreRequestURLs.getTeams(id));
    return result;
  }

  @override
  Future getWebsockets(String id) {
    // TODO: implement getWebsockets
    throw UnimplementedError();
  }
}
